Space Backgrounds Pixel Art Pack - Free Sample

This is a set of pixel art backgrounds for your space game.

This free sample pack includes 1 background in 5 different color variants (320x180 px and upscaled versions 640x360px)​.

If you like this sample pack, please consider getting the full pack. The full pack includes 3 additional space backgrounds, each coming in 5 different color variants.

---

LICENSE: You may use these backgrounds both in free and commercial projects. You can modify the images to suit your own needs. Credit is not necessary, but appreciated.  You may not redistribute or resell the images on their own or as part of an asset pack compilation. 

---

Art by Norma2D.

Twitter - https://twitter.com/norma_2d

DeviantArt - https://www.deviantart.com/norma2d

---

If you like what I do and would like to support me:

Ko-fi - https://ko-fi.com/norma2d

---

Thank you! 